#! /bin/bash

if [ $# -ne 2 ]
then
        echo "Le nombre de paramètres est incorrect !"
        exit 1
fi

cat notes2 | grep "$1" | grep "$2" | cut -d'/' -f3
