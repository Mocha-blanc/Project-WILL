#! /bin/bash

sort -nr -t'/' -k3 $1 | head -n1 | cut -d'/' -f1,2 | tr -s "/" " "
