#! /bin/bash

rm -f "$1"

while read line
do
	echo $line >> $1
	echo $line
done

