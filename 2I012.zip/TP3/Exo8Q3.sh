#! /bin/bash

for i in *.save;
do
	message=$i
	echo $message
	mv $i $(echo ${message//".save"/})
done
