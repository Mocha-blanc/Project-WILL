#my_rm-rf.sh
dossier_arg=$1

for elt in $dossier_arg/*
do
 if test -d $elt
 then 
    echo "dir:" $elt
    ./my_rm-rf.sh $emt
 elif test -f $elt
 then
    rm "$elt"
    echo "file :" $elt
 fi
done

rmdir $dossier_arg 
