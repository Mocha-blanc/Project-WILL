#! /bin/bash

if [ $# -ne 2 ]
then 
	  echo "Mauvais parametres"
	  exit 1
fi

if grep -q $1 < $2 # ou if [[ -z $(grep $1 $2) ]] et inverser les 2 echo
then
	echo trouvé
else
	echo non trouvé
fi
