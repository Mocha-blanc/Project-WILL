#! /bin/bash

rm -f "$2"
rm -f tmperror.txt

while read line
do
	echo $line >> $2
	echo $line
	echo "$line" | tr -d '\n' | wc -c >> tmperror.txt
done < $1

