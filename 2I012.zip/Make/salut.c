int main () {
  int h = heure();

  if ((h < 6)||(h>22)) {
    bonnenuit();
  }
  else {
    if (h < 18) {
      bonjour();
    }
    else bonsoir();
  }
  return 0;
}
