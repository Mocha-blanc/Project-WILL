#include <stdio.h>

void bonsoir () {
  printf ("Bonsoir!\n");
}
