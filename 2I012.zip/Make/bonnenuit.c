#include <stdio.h>

void bonnenuit () {
  printf ("Bonne nuit!\n");
}
