#include <stdio.h>

void bonjour () {
  printf ("Bonjour!\n");
}
